﻿using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using Shared.Interfaces;

namespace DataAccess;

public class CustomerRepository: ICustomerService<Customer>
{
    private readonly StoreDBContext context;

    public CustomerRepository(StoreDBContext _context)
    {
        context = _context;
    }

    public async Task<IEnumerable<Customer>> GetAllCustomers()
    {
        return context.Customers;
    }

    public async Task<Customer?> GetCustomerById(int id)
    {
        return await context.Customers.FindAsync(id); ;
    }

    public async Task<Customer?> GetCustomerByEmail(string email)
    {
        return await context.Customers.FirstOrDefaultAsync(c => c.Email == email);
    }


    public async Task AddCustomer(Customer newCustomer)
    {
        await context.Customers.AddAsync(newCustomer);
        await context.SaveChangesAsync();
    }

   

    public async Task UpdateCustomer(Customer updatedCustomer)
    {
        var existingCustomer = await context.Customers.FindAsync(updatedCustomer.CustomerId);
        if (existingCustomer != null)
        {
            context.Entry(existingCustomer).CurrentValues.SetValues(updatedCustomer);
            await context.SaveChangesAsync();
        }
    }

    public async Task DeleteCustomer(int id)
    {
        var customerToDelete = await context.Customers.FindAsync(id);
        if (customerToDelete != null)
        {
            context.Customers.Remove(customerToDelete);
            await context.SaveChangesAsync();
        }
    }


}