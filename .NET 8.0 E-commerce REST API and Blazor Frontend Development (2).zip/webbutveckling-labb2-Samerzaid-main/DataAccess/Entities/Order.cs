﻿using System.ComponentModel.DataAnnotations;

namespace DataAccess.Entities;

public class Order
{
    [Key]
    public int OrderId { get; set; }

    public Customer customer { get; set; }

    public List<Product> Products { get; set; } = new List<Product>();
}