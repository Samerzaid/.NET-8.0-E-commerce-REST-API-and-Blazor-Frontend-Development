﻿using System.ComponentModel.DataAnnotations;

namespace DataAccess.Entities;

public class Product
{
    [Key]
    public int ProductNumber { get; set; }

    public string ProductName { get; set; }

    public string ProductDescription { get; set; }

    public double Price { get; set; }

    public int AmountOfProduct { get; set; }

    public string ProductCategory { get; set; }

    public bool Status  { get; set;}

}