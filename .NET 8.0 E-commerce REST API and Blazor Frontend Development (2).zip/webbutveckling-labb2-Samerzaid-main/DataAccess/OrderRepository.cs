﻿using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using Shared.Interfaces;

namespace DataAccess;

public class OrderRepository : IOrderService<Order>
{
    private readonly StoreDBContext _context;

    public OrderRepository(StoreDBContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Order>> GetAllOrders()
    {
        return await _context.Orders.Include(o => o.customer).Include(o => o.Products).ToListAsync();
    }

    public async Task<Order?> GetOrderById(int id)
    {
        return await _context.Orders.Include(o => o.customer).Include(o => o.Products).FirstOrDefaultAsync(o => o.OrderId == id);
    }

    public async Task AddOrder(int customerId, List<int> productIds)
    {
        var customer = await _context.Customers.FindAsync(customerId);
        if (customer == null)
        {
            throw new Exception("Customer not found.");
        }

        var products = await _context.Products.Where(p => productIds.Contains(p.ProductNumber)).ToListAsync();
        if (products.Count != productIds.Count)
        {
            throw new Exception("One or more products not found.");
        }

        foreach (var product in products)
        {
            if (product.AmountOfProduct <= 0)
            {
                throw new Exception($"Product '{product.ProductName}' is out of stock.");
            }

            product.AmountOfProduct--;
        }

        var newOrder = new Order
        {
            customer  = customer,
            Products = products
        };

        _context.Orders.Add(newOrder);
        await _context.SaveChangesAsync();
    }


   
}
