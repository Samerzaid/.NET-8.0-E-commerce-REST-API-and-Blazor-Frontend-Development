﻿using System.Threading.Channels;
using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using Shared.Interfaces;

namespace DataAccess;

public class ProductRepository : IProductService<Product>
{

    private readonly StoreDBContext context;

    public ProductRepository(StoreDBContext _context)
    {
        context = _context;
    }
    public async Task AddProduct(Product newProduct)
    {
        await context.Products.AddAsync(newProduct);
        await context.SaveChangesAsync();
    }

    public async Task<IEnumerable<Product>> GetAllProducts()
    {
        return context.Products;
    }

    public async Task<Product?> GetProductById(int id)
    {
        return await context.Products.FindAsync(id);
    }

    public async Task<Product?> GetProductByName(string email)
    {
        return await context.Products.FirstOrDefaultAsync(c => c.ProductName == email);
    }



    public async Task UpdateProduct(Product updatedProduct)
    {
        var existingProduct = await context.Products.FindAsync(updatedProduct.ProductNumber);
        if (existingProduct != null)
        {
            context.Entry(existingProduct).CurrentValues.SetValues(updatedProduct);
            await context.SaveChangesAsync();
        }
    }

    public async Task DeleteProduct(int id)
    {
        var productToDelete = await context.Products.FindAsync(id);
        if (productToDelete != null)
        {
            context.Products.Remove(productToDelete);
            await context.SaveChangesAsync();
        }
    }


}