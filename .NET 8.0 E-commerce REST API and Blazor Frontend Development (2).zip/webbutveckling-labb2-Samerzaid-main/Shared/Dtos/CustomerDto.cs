﻿using System.ComponentModel.DataAnnotations;

namespace Shared.Dtos;

public class CustomerDto
{
    public int CustomerId { get; set; }
    [Required]
    public string FirstName { get; set; }
    [Required]

    public string LastName { get; set; }

    [EmailAddress]
    public string Email { get; set; }

    [Phone]
    public string TelefonNumber { get; set; }

    public string Address { get; set; }
}