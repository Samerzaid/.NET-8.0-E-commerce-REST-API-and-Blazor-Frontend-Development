﻿namespace Shared.Dtos;

public class OrderDto
{
    public int OrderId { get; set; }

    public CustomerDto customer { get; set; }

    public List<ProductDto> Products { get; set; } = new List<ProductDto>();
}