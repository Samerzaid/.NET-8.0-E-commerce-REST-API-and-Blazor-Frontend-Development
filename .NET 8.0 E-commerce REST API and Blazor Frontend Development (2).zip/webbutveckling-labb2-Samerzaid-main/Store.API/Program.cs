using DataAccess;
using DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using Shared.Dtos;
using Shared.Interfaces;

var builder = WebApplication.CreateBuilder(args);

var connectionString = builder.Configuration.GetConnectionString("StoreDBContext");
builder.Services.AddDbContext<StoreDBContext>(
    options => options.UseSqlServer(connectionString));

builder.Services.AddScoped<IProductService<Product>,ProductRepository>();
builder.Services.AddScoped<ICustomerService<Customer>,CustomerRepository>();
builder.Services.AddScoped<IOrderService<Order>, OrderRepository>();


var app = builder.Build();

app.MapGet("/Products", async (IProductService<Product> repo) =>
{
    return await repo.GetAllProducts();
    
});



app.MapGet("/Products/id/{id}", async (IProductService<Product> repo , int id) =>
{
    var product = await repo.GetProductById(id);

    if (product is null)
    {
        return Results.NotFound($"No product exists with the given Id: {id}");
    }

    

    return Results.Ok(product);

});


app.MapGet("/Products/productName/{productName}", async (IProductService<Product> repo, string productName) =>
{
    var allProductss = await repo.GetAllProducts();
    var product = allProductss.Where(p => p.ProductName.Equals(productName));
    if (product is null || productName.Count() <= 0)
    {
        return Results.NotFound();
    }
    return Results.Ok(product);
});


app.MapPost("/Products", async (IProductService<Product> repo, Product newProduct) =>
{
    var existingProduct = await repo.GetProductById(newProduct.ProductNumber);

    if (existingProduct is not null)
    {
        return Results.BadRequest($"A product is already registered with the id: {newProduct.ProductNumber}");
    }
    await repo.AddProduct(newProduct);

    return Results.Ok();
});

app.MapPut("/Products/{id}", async (IProductService<Product> repo, int id, Product updatedProduct) =>
{
    if (id != updatedProduct.ProductNumber)
    {
        return Results.BadRequest("Product number mismatch");
    }

    await repo.UpdateProduct(updatedProduct);

    return Results.Ok();
});

app.MapDelete("/Products/{id}", async (IProductService<Product> repo, int id) =>
{
    await repo.DeleteProduct(id);

    return Results.Ok();
});



app.MapGet("/Customers", async (ICustomerService<Customer> repo) =>
{
    return await repo.GetAllCustomers();
});

app.MapGet("/Customers/id/{id}", async (ICustomerService<Customer> repo, int id) =>
{
    var customer = await repo.GetCustomerById(id);

    if (customer is null)
    {
        return Results.NotFound($"No customer exists with the given Id: {id}");
    }

    return Results.Ok(customer);

});

app.MapGet("/Customers/email/{emailAddress}", async (ICustomerService<Customer> repo, string emailAddress) =>
{
    var allCustomers = await repo.GetAllCustomers();
    var email = allCustomers.Where(p => p.Email.Equals(emailAddress));
    if (email is null || emailAddress.Count() <= 0)
    {
        return Results.NotFound();
    }
    return Results.Ok(email);
});

app.MapPost("/Customers", async (ICustomerService<Customer> repo, Customer newCustomer) =>
{
    var existingProduct = await repo.GetCustomerById(newCustomer.CustomerId);

    if (existingProduct is not null)
    {
        return Results.BadRequest($"A product is already registered with the id: {newCustomer.CustomerId}");
    }
    await repo.AddCustomer(newCustomer);

    return Results.Ok();
});


app.MapPut("/Customers/{id}", async (ICustomerService<Customer> repo, int id, Customer updatedCustomer) =>
{
    if (id != updatedCustomer.CustomerId)
    {
        return Results.BadRequest("Customer number mismatch");
    }

    await repo.UpdateCustomer(updatedCustomer);

    return Results.Ok();
});

app.MapDelete("/Customers/{id}", async (ICustomerService<Customer> repo, int id) =>
{
    await repo.DeleteCustomer(id);

    return Results.Ok();
});




app.MapGet("/Orders", async (IOrderService<Order> repo) =>
{
    return await repo.GetAllOrders();
});

app.MapGet("/Orders/id/{id}", async (IOrderService<Order> repo, int id) =>
{
    var order = await repo.GetOrderById(id);

    if (order is null)
    {
        return Results.NotFound($"No order exists with the given Id: {id}");
    }

    return Results.Ok(order);
});


app.MapPost("/Orders", async (IOrderService<Order> repo, int customerId, List<int> productIds) =>
{
    await repo.AddOrder(customerId, productIds);

    return Results.Ok();
});



app.Run();

