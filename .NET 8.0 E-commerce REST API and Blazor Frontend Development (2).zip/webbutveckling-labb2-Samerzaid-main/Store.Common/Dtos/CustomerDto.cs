﻿using System.ComponentModel.DataAnnotations;

namespace Store.Common.Dtos;

public class CustomerDto
{
    [Required]
    public string FirstName { get; set; }
    [Required]

    public string LastName { get; set; }

    [EmailAddress]
    public string Email { get; set; }

    [Phone]
    public string TelefonNumber { get; set; }

    public string Address { get; set; }
}