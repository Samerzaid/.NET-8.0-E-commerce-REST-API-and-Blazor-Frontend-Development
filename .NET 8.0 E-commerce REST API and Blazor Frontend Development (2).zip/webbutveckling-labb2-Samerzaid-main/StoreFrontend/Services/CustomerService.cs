﻿using Shared.Dtos;
using Shared.Interfaces;

namespace StoreFront.Services;

public class CustomerService : ICustomerService<CustomerDto>
{
    private readonly HttpClient _httpClient;

    public CustomerService(IHttpClientFactory factory)
    {
        _httpClient = factory.CreateClient("StoreApi");
    }

    public async Task<IEnumerable<CustomerDto>> GetAllCustomers()
    {
        var response = await _httpClient.GetAsync("Customers");

        if (!response.IsSuccessStatusCode)
        {
            return Enumerable.Empty<CustomerDto>();
        }

        var result = await response.Content.ReadFromJsonAsync<List<CustomerDto>>();
        return result ?? Enumerable.Empty<CustomerDto>();
    }

    public async Task<CustomerDto?> GetCustomerById(int id)
    {
        throw new NotImplementedException();
    }

    public async Task AddCustomer(CustomerDto newCustomer)
    {
        var response = await _httpClient.PostAsJsonAsync("/Customers", newCustomer);

        if (!response.IsSuccessStatusCode)
        {
            return;
        }
    }
    public async Task UpdateCustomer(CustomerDto updatedCustomer)
    {
        var response = await _httpClient.PutAsJsonAsync($"/Customers/{updatedCustomer.CustomerId}", updatedCustomer);

        if (!response.IsSuccessStatusCode)
        {
            throw new Exception($"Failed to update customer. Status code: {response.StatusCode}");
        }
    }

    public async Task<CustomerDto?> GetCustomerByEmail(string email)
    {
        var response = await _httpClient.GetAsync($"Customers/email/{email}");

        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var result = await response.Content.ReadFromJsonAsync<List<CustomerDto>>();
        return result.FirstOrDefault();
    }


    public async Task DeleteCustomer(int id)
    {
        var response = await _httpClient.DeleteAsync($"/Customers/{id}");

        if (!response.IsSuccessStatusCode)
        {
            throw new Exception($"Failed to delete customer. Status code: {response.StatusCode}");
        }
    }


}