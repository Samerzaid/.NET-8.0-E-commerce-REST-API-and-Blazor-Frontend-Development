﻿
using Shared.Dtos;
using Shared.Interfaces;

namespace StoreFront.Services
{
    public class OrderService : IOrderService<OrderDto>
    {
        private readonly HttpClient _httpClient;

        public OrderService(IHttpClientFactory factory)
        {
            _httpClient = factory.CreateClient("StoreApi");
        }

        public async Task<IEnumerable<OrderDto>> GetAllOrders()
        {
            var response = await _httpClient.GetAsync("Orders");

            if (!response.IsSuccessStatusCode)
            {
                return Enumerable.Empty<OrderDto>();
            }

            return await response.Content.ReadFromJsonAsync<IEnumerable<OrderDto>>();
        }

        public async Task<OrderDto?> GetOrderById(int id)
        {
            var response = await _httpClient.GetAsync($"Orders/{id}");

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            return await response.Content.ReadFromJsonAsync<OrderDto>();
        }

        public async Task AddOrder(int customerId, List<int> productIds)
        {

            var response = await _httpClient.PostAsJsonAsync($"Orders?customerId={customerId}", productIds);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Failed to add order. Status code: {response.StatusCode}");
            }
        }
    }
}
