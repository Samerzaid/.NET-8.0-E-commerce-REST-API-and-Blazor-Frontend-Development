﻿using Shared.Dtos;
using Shared.Interfaces;
using StoreFrontend.Components.Pages;

namespace StoreFront.Services;

public class ProductService : IProductService<ProductDto>
{
    private readonly HttpClient _httpClient;

    public ProductService(IHttpClientFactory factory)
    {
        _httpClient = factory.CreateClient("StoreApi");
    }

    public async Task<IEnumerable<ProductDto>> GetAllProducts()
    {
        var response = await _httpClient.GetAsync("Products");

        if (!response.IsSuccessStatusCode)
        {
            return Enumerable.Empty<ProductDto>();
        }

        var result = await response.Content.ReadFromJsonAsync<List<ProductDto>>();
        return result ?? Enumerable.Empty<ProductDto>();


    }


    public async Task<ProductDto?> GetProductById(int id)
    {
        var response = await _httpClient.GetAsync($"Products/{id}");

        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        return await response.Content.ReadFromJsonAsync<ProductDto>();
    }

    public async Task AddProduct(ProductDto newProduct)
    {
        var response = await _httpClient.PostAsJsonAsync("/Products", newProduct);

        if (!response.IsSuccessStatusCode)
        {
            return;
        }
    }
    public async Task UpdateProduct(ProductDto updatedProduct)
    {
        var response = await _httpClient.PutAsJsonAsync($"/Products/{updatedProduct.ProductNumber}", updatedProduct);

        if (!response.IsSuccessStatusCode)
        {
            throw new Exception($"Failed to update product. Status code: {response.StatusCode}");
        }
    }

    public async Task<ProductDto?> GetProductByName(string productName)
    {
        var response = await _httpClient.GetAsync($"Products/productName/{productName}");

        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        var result = await response.Content.ReadFromJsonAsync<List<ProductDto>>();
        return result.FirstOrDefault();
    }


    public async Task DeleteProduct(int id)
    {
        var response = await _httpClient.DeleteAsync($"/Products/{id}");

        if (!response.IsSuccessStatusCode)
        {
            throw new Exception($"Failed to delete product. Status code: {response.StatusCode}");
        }
    }
}
